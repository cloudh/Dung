package imus.game.dung;

import android.content.Context;

public class Buddhist extends Item {

	Buddhist(Context context, int _x, int _y, int _sy) {
		super(context, _x, _y, _sy);
		// TODO Auto-generated constructor stub
	}

}
